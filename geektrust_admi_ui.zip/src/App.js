import logo from "./logo.svg";
import "./App.css";
import AdminUI from "./components/AdminUI";

function App() {
  return (
    <div className="App">
      <AdminUI />
    </div>
  );
}

export default App;
